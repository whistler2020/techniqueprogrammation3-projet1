<?php 
  $username="root";   // utilisateur par défaut, on le changera lorsqu'on abordera le volet sécurité
  $password="mysql";       // mot de passe par défaut de l'utilisateur root, on le changera lorsqu'on abordera le volet sécurité
  $host="localhost";  // url de votre serveur local, à modifier lors du déploiement en ligne
  $database="dbforfaitvoyage";  // nom de la base de données utilisée par votre site
?>